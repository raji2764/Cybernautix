import { initializeApp } from "firebase/app"; //the line which we get when we create a new project
import { getDatabase } from "firebase/database";
const firebaseConfig = {
  apiKey: "AIzaSyCCWGqnD4hbdRr3CNcIc0exeKn4O3jIuMw",
  authDomain: "hazel-hall-404911.firebaseapp.com",
  projectId: "hazel-hall-404911",
  storageBucket: "hazel-hall-404911.appspot.com",
  messagingSenderId: "1058004847288",
  appId: "1:1058004847288:web:8b0ea8a95a1003d116c24d",
  measurementId: "G-5V9EBMCBK4",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
