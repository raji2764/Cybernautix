import React, { useState, useEffect } from "react";
import "./App.css";
import { ref, set, onValue } from "firebase/database";
import { db } from "./config";
function App() {
  const [entryCount, setEntryCount] = useState(0); //if i use set func at multiple places for same variable name (infinite rerender error will come)
  const [Name, setName] = useState("");
  const [CName, setAge] = useState("");
  const [Email, setEmail] = useState("");
  const [Password, setPassword] = useState("");
  const [Confirm, setConfirm] = useState("");
  const [Phone, setPhone] = useState(0);
  const [Blitzbyte, setBlitzbyte] = useState(0);
  const [Uxplorer, setUxplorer] = useState(0);
  const [PaperPinnacle, setPaperpinnacle] = useState(0);
  const [WebVortex, setWebVortex] = useState(0);
  const [Pixel, setPixel] = useState(0);
  const [LexiCharm, setLexiCharm] = useState(0);
  const [Connections, setConnections] = useState(0);
  const [Smirk, setSmirk] = useState(0);
  let Id = "CY";
  const countEntriesInCollection = () => {
    const collectionRef = ref(db, "cyber");
    // Listen for value changes at the collection reference
    onValue(collectionRef, (snapshot) => {
      let count = 0;
      snapshot.forEach(() => {
        count++;
      });
      // Call the callback function with the count
      setEntryCount(count);
    });
  };

  useEffect(() => {
    // Call the function to count entries
    countEntriesInCollection();
  }, []);

  const addDataToRealtimeDatabase = () => {
    const SubId = entryCount + 100;
    let L = SubId.toString();
    let F = Id.concat(L);
    const databaseRef = ref(db, `cyber/${F}`);
    //const customKeyRef = ref(databaseRef, "1");
    set(databaseRef, {
      Name: Name, //the second value is the use state value , the keys are defined by us
      ClgName: CName,
      Email: Email,
      Phone: Phone,
      Password: Password,
      Confirm: Confirm,
      Blitzbyte: Blitzbyte,
      Uxplorer: Uxplorer,
      PaperPinnacle: PaperPinnacle,
      WebVortex: WebVortex,
      Pixel: Pixel,
      LexiCharm: LexiCharm,
      Connections: Connections,
      Smirk: Smirk,
    });
  };
  function ClgName(e) {
    setAge(e.target.value);
    console.log(CName);
  }

  return (
    <div>
      <h1 className="title">Fetch Details</h1>
      <form>
        <label>
          enter your name:
          <input
            placeholder="your name"
            value={Name}
            type="text"
            onChange={(e) => setName(e.target.value)}
          />
        </label>
        <br />
        <label>
          Enter your college name:
          <input
            placeholder="college"
            type="text"
            value={CName}
            onChange={ClgName}
          />
        </label>
        <br />
        <label>
          enter your Email:
          <input
            placeholder="Your Email"
            value={Email}
            type="email"
            onChange={(e) => setEmail(e.target.value)}
          />
        </label>
        <br />
        <label>
          Enter your Password:
          <input
            placeholder="Password"
            type="password"
            value={Password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <br />
        <label>
          Confirm your Password:
          <input
            placeholder="confirm Password"
            type="password"
            value={Confirm}
            onChange={(e) => setConfirm(e.target.value)}
          />
        </label>
        <br />
        <label>
          Enter your Phone Number:
          <input
            placeholder="Phone number"
            type="tel"
            value={Phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        </label>
        <br />
        <label>
          Technical Events
          <input
            type="checkbox"
            value={Blitzbyte}
            onClick={(e) => setBlitzbyte(1)}
          />
          <span>Blitzbyte</span>
          <input
            type="checkbox"
            value={Uxplorer}
            onClick={(e) => setUxplorer(1)}
          />
          <span>UXplorer</span>
          <input
            type="checkbox"
            value={PaperPinnacle}
            onClick={(e) => setPaperpinnacle(1)}
          />
          <span>PaperPinnacle</span>
          <input
            type="checkbox"
            value={WebVortex}
            onClick={(e) => setWebVortex(1)}
          />
          <span>WebVortex</span>
          <input type="checkbox" value={Pixel} onClick={(e) => setPixel(1)} />
          <span>PixelPlayGround</span>
          <br />
        </label>
        <label>
          Non-Technical events
          <input
            type="checkbox"
            value={LexiCharm}
            onClick={(e) => setLexiCharm(1)}
          />
          <span>LexiCharm</span>
          <input
            type="checkbox"
            value={Connections}
            onClick={(e) => setConnections(1)}
          />
          <span>CON-TAC-TIX</span>
          <input type="checkbox" value={Smirk} onClick={(e) => setSmirk(1)} />
          <span>Smirk</span>
        </label>
      </form>
      <button onClick={addDataToRealtimeDatabase}>Add data</button>
    </div>
  );
}

export default App;
